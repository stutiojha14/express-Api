var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser')
var mysql = require('mysql');
const con = require('./connection')
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var fetchRouter = require('./routes/fetchData');

var app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/urlinfo/:host/:query', function(req, res, next) {
    console.log(req.params)
    con.query("SELECT count(*) AS infected FROM userinfo where host ='"+req.params.host+"' AND query='"+ req.params. query+"'", function (err, result, fields) {
        if (err) throw err;
        res.send(JSON.stringify(result));
        console.log(result);
    });
});

module.exports = app;
