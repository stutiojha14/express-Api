Run npm install
Import data.csv file to myswl databse
run node server - node app.js
Open browser and hit http://localhost:3000/urlinfo/dsds/fdfd
Result will be fetched from server