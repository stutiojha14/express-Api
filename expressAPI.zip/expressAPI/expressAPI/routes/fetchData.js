var express = require('express');
var router = express.Router();
const con = require('../connection')

/* GET users listing. */
router.get('/', function(req, res, next) {
    console.log(req.params)
    console.log(req.body)
    console.log(req.query)
    con.query("SELECT * FROM userinfo", function (err, result, fields) {
        if (err) throw err;
        res.send(JSON.stringify(result));
        //console.log(result);
    });
});
module.exports = router;
